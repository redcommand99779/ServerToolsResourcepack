#version 330

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:sample_lightmap.glsl>
#endif

#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
in ivec2 UV2;
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
uniform sampler2D Sampler2;
out float sphericalVertexDistance;
out float cylindricalVertexDistance;
#endif

out vec4 vertexColor;
out vec2 texCoord0;

#ifdef IS_GUI
out vec2 mmPos;
flat out vec4 mmClip;

// Server Tools minimap: a glyph whose colour has red 0x70..0x7F is not drawn where the text layout puts it but at a place of the minimap in the
// top right corner of the screen. red - 0x70 = kind of glyph (its size is known here), green - 64 and blue - 64 = position inside the minimap.
vec2 mmGlyphSize(int kind) {
    if (kind == 0) return vec2(32.0, 32.0);   // map tile
    if (kind == 1) return vec2(104.0, 104.0); // frame
    if (kind == 2 || kind == 3) return vec2(3.0, 3.0); // small dots (zone rings)
    if (kind == 4 || kind == 5 || kind == 9) return vec2(5.0, 5.0); // dots
    if (kind == 6) return vec2(11.0, 11.0);   // arrow of the player
    if (kind == 7) return vec2(9.0, 9.0);     // supply drop
    if (kind == 8) return vec2(13.0, 13.0);   // battle bus
    return vec2(0.0, 0.0);
}
#endif

void main() {
    vec3 pos = Position;
    vec4 col = Color;
#ifdef IS_GUI
    mmPos = Position.xy;
    mmClip = vec4(0.0);
    vec3 c = floor(Color.rgb * 255.0 + 0.5);
    if (c.r >= 112.0 && c.r < 128.0 && Color.a > 0.5) {
        int kind = int(c.r) - 112;
        vec2 size = mmGlyphSize(kind);
        float guiWidth = 2.0 / ProjMat[0][0];
        vec2 origin = vec2(guiWidth - 103.0, 7.0);
        int corner = gl_VertexID & 3;                       // 0 top left, 1 bottom left, 2 bottom right, 3 top right
        vec2 offset = vec2((corner == 2 || corner == 3) ? 1.0 : 0.0, (corner == 1 || corner == 2) ? 1.0 : 0.0);
        pos.xy = origin + vec2(c.g - 64.0, c.b - 64.0) + offset * size;
        mmPos = pos.xy;
        if (kind != 1) mmClip = vec4(origin, origin + vec2(96.0, 96.0)); // everything except the frame is cut off at the edge of the map
        col = vec4(1.0, 1.0, 1.0, Color.a);
    }
#endif
    gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = col * sample_lightmap(Sampler2, UV2);
#else
    vertexColor = col;
#endif
    texCoord0 = UV0;
}
